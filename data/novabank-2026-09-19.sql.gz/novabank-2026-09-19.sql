--
-- PostgreSQL database dump
--

\restrict 27UyqQ3RqTwqd8XDhg6CCEPenbS1dbaAzZddn381ms54SqaixzGc3xvz6QQflgN

-- Dumped from database version 18.6 (6569466)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: categoria_transaccion; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.categoria_transaccion AS ENUM (
    'COMPRAS',
    'TRANSFERENCIAS',
    'QR',
    'INGRESOS',
    'RETIROS',
    'SERVICIOS'
);


ALTER TYPE public.categoria_transaccion OWNER TO neondb_owner;

--
-- Name: proposito_otp; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.proposito_otp AS ENUM (
    'REGISTER',
    'PASSWORD_RESET',
    'TRANSFER',
    'PROFILE_UPDATE'
);


ALTER TYPE public.proposito_otp OWNER TO neondb_owner;

--
-- Name: resultado_inicio_sesion; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.resultado_inicio_sesion AS ENUM (
    'SUCCESS',
    'INVALID_CREDENTIALS',
    'ACCOUNT_LOCKED',
    'ACCOUNT_INACTIVE'
);


ALTER TYPE public.resultado_inicio_sesion OWNER TO neondb_owner;

--
-- Name: tipo_transaccion; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.tipo_transaccion AS ENUM (
    'CREDIT',
    'DEBIT'
);


ALTER TYPE public.tipo_transaccion OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO neondb_owner;

--
-- Name: beneficiarios; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.beneficiarios (
    id text NOT NULL,
    usuario_id text NOT NULL,
    name text NOT NULL,
    bank text NOT NULL,
    numero_cuenta text NOT NULL,
    initials text NOT NULL,
    inactive boolean DEFAULT false NOT NULL,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.beneficiarios OWNER TO neondb_owner;

--
-- Name: codigos_verificacion; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.codigos_verificacion (
    id text CONSTRAINT email_otps_id_not_null NOT NULL,
    correo text CONSTRAINT email_otps_email_not_null NOT NULL,
    proposito public.proposito_otp CONSTRAINT email_otps_purpose_not_null NOT NULL,
    codigo_hash text CONSTRAINT "email_otps_codeHash_not_null" NOT NULL,
    intentos integer DEFAULT 0 CONSTRAINT email_otps_attempts_not_null NOT NULL,
    expira_en timestamp(3) without time zone CONSTRAINT "email_otps_expiresAt_not_null" NOT NULL,
    consumido_en timestamp(3) without time zone,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "email_otps_createdAt_not_null" NOT NULL
);


ALTER TABLE public.codigos_verificacion OWNER TO neondb_owner;

--
-- Name: cuentas; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.cuentas (
    id text NOT NULL,
    usuario_id text NOT NULL,
    numero_cuenta text NOT NULL,
    cci text NOT NULL,
    numero_tarjeta text NOT NULL,
    vencimiento_tarjeta text NOT NULL,
    saldo_disponible numeric(12,2) DEFAULT 0 NOT NULL,
    saldo_retenido numeric(12,2) DEFAULT 0 NOT NULL,
    linea_credito numeric(12,2) DEFAULT 0 NOT NULL,
    deuda_tarjeta numeric(12,2) DEFAULT 0 NOT NULL,
    dia_corte integer DEFAULT 28 NOT NULL,
    tarjeta_bloqueada boolean DEFAULT false NOT NULL,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    actualizado_en timestamp(3) without time zone NOT NULL,
    geo_internacional boolean DEFAULT false NOT NULL,
    geo_peru boolean DEFAULT true NOT NULL,
    limite_cajero numeric(12,2) DEFAULT 700 NOT NULL,
    limite_en_linea numeric(12,2) DEFAULT 1500 NOT NULL
);


ALTER TABLE public.cuentas OWNER TO neondb_owner;

--
-- Name: eventos_inicio_sesion; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.eventos_inicio_sesion (
    id text CONSTRAINT login_events_id_not_null NOT NULL,
    usuario_id text,
    correo text CONSTRAINT login_events_email_not_null NOT NULL,
    resultado public.resultado_inicio_sesion CONSTRAINT login_events_result_not_null NOT NULL,
    ip text,
    agente_usuario text,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "login_events_createdAt_not_null" NOT NULL
);


ALTER TABLE public.eventos_inicio_sesion OWNER TO neondb_owner;

--
-- Name: eventos_verificacion_facial; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.eventos_verificacion_facial (
    id text CONSTRAINT face_verification_events_id_not_null NOT NULL,
    dni text CONSTRAINT face_verification_events_dni_not_null NOT NULL,
    coincidio boolean CONSTRAINT face_verification_events_matched_not_null NOT NULL,
    confianza double precision CONSTRAINT face_verification_events_confidence_not_null NOT NULL,
    ip text,
    agente_usuario text,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "face_verification_events_createdAt_not_null" NOT NULL
);


ALTER TABLE public.eventos_verificacion_facial OWNER TO neondb_owner;

--
-- Name: notificaciones; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notificaciones (
    id text NOT NULL,
    usuario_id text NOT NULL,
    titulo text NOT NULL,
    cuerpo text NOT NULL,
    icon text NOT NULL,
    icono_fondo text NOT NULL,
    icono_color text NOT NULL,
    no_leido boolean DEFAULT true NOT NULL,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notificaciones OWNER TO neondb_owner;

--
-- Name: referencias_faciales; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.referencias_faciales (
    id text CONSTRAINT face_references_id_not_null NOT NULL,
    usuario_id text CONSTRAINT "face_references_userId_not_null" NOT NULL,
    foto_dni_url text CONSTRAINT "face_references_dniPhotoUrl_not_null" NOT NULL,
    foto_selfie_url text CONSTRAINT "face_references_selfiePhotoUrl_not_null" NOT NULL,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "face_references_createdAt_not_null" NOT NULL,
    actualizado_en timestamp(3) without time zone CONSTRAINT "face_references_updatedAt_not_null" NOT NULL
);


ALTER TABLE public.referencias_faciales OWNER TO neondb_owner;

--
-- Name: tokens_renovacion; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tokens_renovacion (
    id text CONSTRAINT refresh_tokens_id_not_null NOT NULL,
    usuario_id text CONSTRAINT "refresh_tokens_userId_not_null" NOT NULL,
    token_hash text CONSTRAINT "refresh_tokens_tokenHash_not_null" NOT NULL,
    agente_usuario text,
    ip text,
    expira_en timestamp(3) without time zone CONSTRAINT "refresh_tokens_expiresAt_not_null" NOT NULL,
    revocado_en timestamp(3) without time zone,
    reemplazado_por_token_hash text,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "refresh_tokens_createdAt_not_null" NOT NULL
);


ALTER TABLE public.tokens_renovacion OWNER TO neondb_owner;

--
-- Name: transacciones; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.transacciones (
    id text NOT NULL,
    cuenta_id text NOT NULL,
    tipo public.tipo_transaccion NOT NULL,
    categoria public.categoria_transaccion NOT NULL,
    nombre text NOT NULL,
    meta text NOT NULL,
    monto numeric(12,2) NOT NULL,
    icon text NOT NULL,
    icono_fondo text NOT NULL,
    icono_color text NOT NULL,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.transacciones OWNER TO neondb_owner;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.usuarios (
    id text CONSTRAINT users_id_not_null NOT NULL,
    correo text CONSTRAINT users_email_not_null NOT NULL,
    telefono text,
    dni text,
    nombre_completo text CONSTRAINT "users_fullName_not_null" NOT NULL,
    contrasena_hash text CONSTRAINT "users_passwordHash_not_null" NOT NULL,
    esta_activo boolean DEFAULT true CONSTRAINT "users_isActive_not_null" NOT NULL,
    intentos_fallidos integer DEFAULT 0 CONSTRAINT "users_failedLoginAttempts_not_null" NOT NULL,
    bloqueado_hasta timestamp(3) without time zone,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "users_createdAt_not_null" NOT NULL,
    actualizado_en timestamp(3) without time zone CONSTRAINT "users_updatedAt_not_null" NOT NULL,
    alerta_compra boolean DEFAULT true NOT NULL,
    alerta_login boolean DEFAULT true NOT NULL,
    alerta_promo boolean DEFAULT false NOT NULL,
    alerta_retiro boolean DEFAULT true NOT NULL
);


ALTER TABLE public.usuarios OWNER TO neondb_owner;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
590422ec-a70a-4ac5-b3c3-bdaef98fa561	65c3dc035de38d2f886549df406ab89fc92e70ebfb55b8392661258dfb60078c	2026-09-12 19:05:43.450393+00	20260912190541_init	\N	\N	2026-09-12 19:05:42.692427+00	1
8d8e7385-60c0-4d53-804b-58fd865e3af1	6a73f277dc1803491b309e87ea7cf19edf2b50e912bb6b35f972b9095ce9e096	2026-09-13 03:02:30.830654+00	20260913030228_add_otp_and_face_verification	\N	\N	2026-09-13 03:02:29.394038+00	1
d553e486-6615-4f66-8cf3-eca0ff54db96	5c3d832ac6d1c58cbe8eb7daf67396f8f316b1b7ba1191d52119be66ed99e5c4	2026-09-14 12:27:44.342375+00	20260914122742_add_face_reference	\N	\N	2026-09-14 12:27:43.602455+00	1
fd2a5b87-c0ba-49b0-bdf2-1b1c472f9b3d	ee85135dd98960634addf20d2bf3159e7877c3672b2c8360f66ac6ec0fce27e6	2026-09-17 19:44:48.821777+00	20260917150000_rename_to_spanish	\N	\N	2026-09-17 19:44:47.972103+00	1
564d7224-8b38-4fbb-bbb9-2de0896b245e	4d8562224b951709362bbcd278c9dc7c91fdb69fc02eaf530b2c1652a1ad4f3b	2026-09-19 00:36:26.291741+00	20260918160000_add_password_reset_otp_purpose	\N	\N	2026-09-19 00:36:25.484237+00	1
fd626297-ffeb-4588-a53a-ff7ea9e0297e	b0de92484c4ab0d761b3c30fc861b757dfda121034de5f812d75aee450df5a5f	2026-09-19 03:24:05.24589+00	20260919032338_add_account_and_transactions	\N	\N	2026-09-19 03:24:04.41899+00	1
1c28bcd8-349d-4a6e-8f32-50f9aa02ef73	c17453eba93b35bf4e9bdbdc821355a216615d767dce3f68e33c85a1756fdf6e	2026-09-19 03:45:50.14468+00	20260919034548_add_notifications	\N	\N	2026-09-19 03:45:49.341632+00	1
026427bd-4d7e-4c9c-b0a8-8fc136d45fe2	7341b29b51448a70650f43da76932af8c4a5063ca45953ca45db7c34424909a8	2026-09-19 04:41:54.277287+00	20260919044152_add_payees_and_transfer_otp	\N	\N	2026-09-19 04:41:53.430787+00	1
fb529ff1-3f92-4184-b875-3306be410745	3ee09c0103478b39a7b64c0b4237a4525a35ff5bdcb5190b86cfc81128808df0	2026-09-19 05:13:25.836412+00	20260919051251_add_profile_update_otp	\N	\N	2026-09-19 05:13:25.105544+00	1
a820f89c-8869-424e-8da4-1fa430f74edb	9c916c48231b9dbf0f4daf41e8bc371ebbecdd9a7f55ff49491860bf78afb201	2026-09-19 06:00:22.662474+00	20260919055944_add_security_prefs_and_limits	\N	\N	2026-09-19 06:00:21.889431+00	1
\.


--
-- Data for Name: beneficiarios; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.beneficiarios (id, usuario_id, name, bank, numero_cuenta, initials, inactive, creado_en) FROM stdin;
906d100e-fe70-4f3b-b373-ee5894506972	5446981a-a39f-44cc-a506-72a205d06a99	Marco Salazar	BCP	···8841	MS	f	2026-09-19 04:53:03.814
d14e8633-e073-4777-894b-8ab8d45c00d5	5446981a-a39f-44cc-a506-72a205d06a99	Camila Ríos	Interbank	···2290	CR	f	2026-09-19 04:53:03.814
fa20a695-4d3a-4784-a525-ea7de5338a56	5446981a-a39f-44cc-a506-72a205d06a99	Cuenta de prueba	BBVA	···0000	CP	t	2026-09-19 04:53:03.814
\.


--
-- Data for Name: codigos_verificacion; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.codigos_verificacion (id, correo, proposito, codigo_hash, intentos, expira_en, consumido_en, creado_en) FROM stdin;
82ec162c-489f-4f82-88cc-d86578d00b42	melanieluyo4@gmail.com	REGISTER	a15ff056e2aec6d14a33dfece7b6d23caf3889b3604b3bf7be12a6185b6659c6	0	2026-09-14 02:53:57.693	2026-09-14 02:44:07.591	2026-09-14 02:43:57.694
14196bbb-abd0-4d21-893b-3f32b455339f	melanieluyo4@gmail.com	REGISTER	688dd8fb81a357b15e039ca261fb4fb3dbfd5c6bf072754235c28eb23bd3ca1d	0	2026-09-14 02:54:07.749	2026-09-14 02:44:20.019	2026-09-14 02:44:07.75
38768ee4-2bd7-4728-9e9e-e2ca24842a1e	melanieluyo4@gmail.com	REGISTER	6f04d05ca2bcb44ae509118709a369e9ce6830d4ffafca40183b9ed965aed83d	0	2026-09-14 02:54:20.178	2026-09-14 02:44:28.553	2026-09-14 02:44:20.179
219cacce-e7fc-4acc-b2cd-23c798a84e91	melanieluyo4@gmail.com	REGISTER	a8433b974fc55664655048f9a22491992e55252fd679c46cb4197131f4033015	0	2026-09-14 02:54:28.712	2026-09-14 02:44:45.757	2026-09-14 02:44:28.713
3d5e701e-7e37-4ddb-a703-6f543ea7d948	melanieluyo4@gmail.com	REGISTER	9fba5d4966fefdf6c0808ae4c5228ef821cf38e40531d61bb3ac71152be02dc7	0	2026-09-14 02:54:45.915	2026-09-14 02:49:04.291	2026-09-14 02:44:45.916
3d721d8f-3182-4109-b317-5da9972da74d	melanieluyo4@gmail.com	REGISTER	95bdacedeedd510297fa05de9055536add9040e01cda058b7407d9519c9281c1	0	2026-09-14 02:59:04.487	2026-09-14 02:51:21.753	2026-09-14 02:49:04.488
0bf6c416-6058-46de-bc2c-4a02e4e7f0df	melanieluyo4@gmail.com	REGISTER	a49bfe3f7bc41ed2cc007992eb4ecebee430bc60045ef374f10ae6bd3c17da15	0	2026-09-14 03:01:21.969	2026-09-14 02:51:34.757	2026-09-14 02:51:21.972
b2adef0a-8cca-485c-9b14-ff7b71617cf5	melanieluyo4@gmail.com	REGISTER	2f6a6361badedaa400178f8931d431cb1c39e5cd81c03315e81e7b98ced8a8f4	0	2026-09-14 03:01:34.916	2026-09-14 02:51:45.29	2026-09-14 02:51:34.917
c060fc30-061f-4f7a-9c0d-cc074b4bad9d	melanieluyo4@gmail.com	REGISTER	49b5b58fceff8100ab3271e7b6ea09b421f2f44a44e658b69531699be3f0f1ec	0	2026-09-14 03:01:45.448	2026-09-14 02:51:56.156	2026-09-14 02:51:45.449
da608220-ad04-40d7-814d-c459e5cc7240	melanieluyo4@gmail.com	REGISTER	9c0340f94a668259c01bad0b24145f4a55be782897c4d23b4cd9cb9e791a0c7f	0	2026-09-14 03:01:56.314	2026-09-14 02:54:25.547	2026-09-14 02:51:56.314
83ebac67-d7ce-465c-af14-9d2c63581fb7	melanieluyo4@gmail.com	REGISTER	35d3d231d64a46a9f65aa23a6393a6506cc7222b713352cbaebd2539e58b8da8	0	2026-09-14 03:04:25.71	2026-09-14 02:54:48.873	2026-09-14 02:54:25.711
3132c844-cf02-480a-9962-2b5c4077cc6b	abrahamjheremycerna@gmail.com	REGISTER	0ececcf317bf519e3e130bd8f9c94c295205c59ee85730485adfc5abfea835a5	0	2026-09-13 03:29:43.997	2026-09-14 11:43:08.028	2026-09-13 03:19:43.998
401283fd-51ef-4c8a-b1b5-8baec50b2aab	melanieluyo4@gmail.com	REGISTER	cb75c4fedc1e5c75344c4df5395df7a6e458fc7d52cdb25c90a4d3df3c7f92d2	1	2026-09-14 12:26:38.618	2026-09-14 12:17:14.839	2026-09-14 12:16:38.619
2645755e-2b63-477c-b2b8-e12cacb7fc2d	abrahamjheremycerna@gmail.com	REGISTER	62bf01e7b40b65a69d468136765f2877265542f38c414b88b987fb6b5ec823aa	0	2026-09-14 11:53:08.242	2026-09-14 11:52:38.782	2026-09-14 11:43:08.243
1ccf0033-5458-444b-8c06-d10a1914477b	abrahamjheremycerna@gmail.com	REGISTER	1c88e32896d839d73bf3ab71eb7f713f2f90469ef2a5165a1f6684c1bbd7fa35	0	2026-09-14 12:02:38.977	\N	2026-09-14 11:52:38.978
7d322f3a-7c01-4060-b2d4-51857337a99e	melanieluyo4@gmail.com	REGISTER	d1a12c7520467592b72d07c6aefa14e0b04ffe629be74476e8710b2e6666efe5	0	2026-09-14 03:04:49.031	2026-09-14 12:16:38.321	2026-09-14 02:54:49.032
4fd1416b-a3bd-4b1c-99e6-a14767420f7c	facetest@novabank.pe	REGISTER	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	0	2026-09-14 12:38:50.08	2026-09-14 12:29:19.815	2026-09-14 12:28:50.081
4c0b27dd-6d37-4c2c-8afa-761d315f1bba	prodfacetest@novabank.pe	REGISTER	481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5	0	2026-09-14 13:00:22.998	2026-09-14 12:50:33.264	2026-09-14 12:50:23
61d3f7a9-4150-4555-b2d0-6de64e7af322	melanieluyo4@gmail.com	PASSWORD_RESET	f982861993eb2f0996471585debceeac9e942b45fe500a9b125b999de0f07cf0	0	2026-09-19 00:58:23.247	2026-09-19 00:56:59.044	2026-09-19 00:48:23.248
a26a958f-cbbe-49fc-b2ee-49c1bf7988c3	melanieluyo4@gmail.com	PASSWORD_RESET	30434b1728f67f5c9b0084e06c6d67ecbc884e255aad171d557e9b8367674d38	0	2026-09-19 01:06:59.301	2026-09-19 01:03:46.561	2026-09-19 00:56:59.302
6e08e738-b3d2-4681-afe9-be086d36f319	melanieluyo4@gmail.com	PASSWORD_RESET	9fa39738a720bdf91ed89714b5bdd23322784e2ee73ff26f2d33deb6d148b7c8	0	2026-09-19 01:13:46.801	2026-09-19 01:04:23.125	2026-09-19 01:03:46.802
916e16ab-0cfd-4560-9345-513efc027228	melanieluyo4@gmail.com	PASSWORD_RESET	eb52585b91a2851671db666110f5600cce7ff2087768da4eebf51c3515a13cfb	2	2026-09-19 01:14:23.28	2026-09-19 01:10:42.893	2026-09-19 01:04:23.281
60a9dc21-b4b7-47ba-9c47-b8a78a62a8ee	melanieluyo4@gmail.com	PASSWORD_RESET	600b0b9743927328a694ff74145cc853c6f32d14a96306674a8b4ccb121e2f44	0	2026-09-19 01:20:43.112	2026-09-19 01:11:26.296	2026-09-19 01:10:43.113
\.


--
-- Data for Name: cuentas; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.cuentas (id, usuario_id, numero_cuenta, cci, numero_tarjeta, vencimiento_tarjeta, saldo_disponible, saldo_retenido, linea_credito, deuda_tarjeta, dia_corte, tarjeta_bloqueada, creado_en, actualizado_en, geo_internacional, geo_peru, limite_cajero, limite_en_linea) FROM stdin;
25ede67f-81ac-41c2-bfe8-d671b0a335c9	5446981a-a39f-44cc-a506-72a205d06a99	191-6135-0783	002-191-72766679056-05	4625366393279051	09/30	0.00	0.00	1500.00	0.00	28	f	2026-09-19 03:29:14.516	2026-09-19 03:29:14.516	f	t	700.00	1500.00
\.


--
-- Data for Name: eventos_inicio_sesion; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.eventos_inicio_sesion (id, usuario_id, correo, resultado, ip, agente_usuario, creado_en) FROM stdin;
3267facc-3780-4a98-afb0-53f620c4dfbf	\N	test@novabank.pe	SUCCESS	::1	curl/8.15.0	2026-09-12 19:06:32.856
7eaed46d-c366-4160-99c2-8dd7e1a0630a	\N	test@novabank.pe	INVALID_CREDENTIALS	::1	curl/8.15.0	2026-09-12 19:06:33.925
c84be1d3-cdf7-455c-b244-90629e355921	\N	test@novabank.pe	SUCCESS	::1	curl/8.15.0	2026-09-12 19:06:49.642
359c7763-e5e4-45f9-b395-41e337abcaa0	\N	abrahamjheremycerna@gmail.com	SUCCESS	10.31.110.3	okhttp/4.9.2	2026-09-12 22:37:08.211
df5945ad-f261-4e64-baf6-081591dec6d4	5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	SUCCESS	10.24.67.139	okhttp/4.9.2	2026-09-19 01:11:50.863
7938470c-47d2-4cf4-8db9-ae4d74249035	5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	SUCCESS	10.24.67.139	okhttp/4.9.2	2026-09-19 01:58:24.618
54a200ac-5a72-4c73-b579-19d59041d66e	5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	SUCCESS	10.30.247.23	okhttp/4.9.2	2026-09-19 02:06:52.036
58d631b0-e768-4d27-884a-bd7bae9e51f9	5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	SUCCESS	10.28.174.130	okhttp/4.9.2	2026-09-19 02:11:48.57
f5b6e1d7-2a6f-4145-b8d4-8e8a35dc7949	5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	SUCCESS	10.28.174.130	okhttp/4.9.2	2026-09-19 02:45:44.496
dbb8def0-b2aa-4d34-8a1e-38d723082a1f	5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	SUCCESS	10.24.67.139	okhttp/4.9.2	2026-09-19 04:30:09.109
4dcd4cea-f17d-4fd0-a3c4-9842de07cd29	5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	SUCCESS	10.24.67.139	okhttp/4.9.2	2026-09-19 05:39:46.759
\.


--
-- Data for Name: eventos_verificacion_facial; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.eventos_verificacion_facial (id, dni, coincidio, confianza, ip, agente_usuario, creado_en) FROM stdin;
75aa5286-a053-4002-af6c-9248e1833d62	76427598	f	67.803	10.31.110.3	okhttp/4.9.2	2026-09-14 02:43:34.617
094aeae8-b0ba-4ed9-b140-1bad6057cd33	76427598	f	63.645	10.29.215.4	okhttp/4.9.2	2026-09-14 02:43:47.577
e8a21680-74e0-4e45-a870-9a87496e2c68	76427598	t	72.955	10.29.215.4	okhttp/4.9.2	2026-09-14 02:43:57.036
883e0ce4-3800-4348-aae6-fcbfb4638750	76427598	t	79.76	10.29.215.4	okhttp/4.9.2	2026-09-14 02:44:07.356
f871c319-76f7-4697-aeef-daae9cce2359	76427598	t	76.818	10.31.110.3	okhttp/4.9.2	2026-09-14 02:44:19.642
9fc89f2b-2039-441d-a3ce-7445594f5f92	76427598	t	83.957	10.31.110.3	okhttp/4.9.2	2026-09-14 02:44:28.297
afab946b-70aa-484f-96e8-9440e79bbefd	76427598	t	83.036	10.29.215.4	okhttp/4.9.2	2026-09-14 02:44:45.325
fee650d0-72f5-4447-b921-32a8a1ec5d9f	76427598	t	80.103	10.28.241.110	okhttp/4.9.2	2026-09-14 02:49:03.915
258c8830-6235-468d-b13a-5f868b93e637	76427598	t	81.21	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:21.406
e70eec55-df1d-494c-bb8e-0a2615949b25	76427598	t	80.783	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:34.419
8298b862-7a91-4e64-925f-faaeef99cc12	76427598	t	78.831	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:44.927
e093d8e1-fbf2-473e-a1f8-eb7d8fc0d2f2	76427598	t	82.929	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:55.869
d791e104-2bb0-4e43-a279-dd917c21c500	76427598	t	80.158	10.28.241.110	okhttp/4.9.2	2026-09-14 02:54:25.253
b825644a-c077-4348-948c-a3df0299dbb1	76427598	t	82.411	10.28.241.110	okhttp/4.9.2	2026-09-14 02:54:48.264
09dfd944-3d6b-4b7f-bee9-7a115db5341d	76427598	t	84.581	10.31.110.3	okhttp/4.9.2	2026-09-14 12:16:37.83
\.


--
-- Data for Name: notificaciones; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notificaciones (id, usuario_id, titulo, cuerpo, icon, icono_fondo, icono_color, no_leido, creado_en) FROM stdin;
\.


--
-- Data for Name: referencias_faciales; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.referencias_faciales (id, usuario_id, foto_dni_url, foto_selfie_url, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: tokens_renovacion; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tokens_renovacion (id, usuario_id, token_hash, agente_usuario, ip, expira_en, revocado_en, reemplazado_por_token_hash, creado_en) FROM stdin;
77288d0b-b841-4386-bca8-ee4cfa1c4fb5	5446981a-a39f-44cc-a506-72a205d06a99	c89777dfad3d4a712ead89a7295ccb6bc7badc42f26e40ebc481bdc0f82edbf2	okhttp/4.9.2	10.24.67.139	2026-10-19 03:37:54.156	2026-09-19 03:53:39.751	6912e281f006daf46ae292fb3b07166ef5b5e2119a1e3c2b7cb22bfa086d9c34	2026-09-19 03:37:54.158
a9b9610c-fec7-4f59-90d4-3713385e4a29	5446981a-a39f-44cc-a506-72a205d06a99	ef080f8aea3fae434e8843df4717d4d192cebe10e7ec410e64c20f7c6585e2f1	okhttp/4.9.2	10.31.110.3	2026-10-14 12:17:17.327	2026-09-14 12:17:33.46	\N	2026-09-14 12:17:17.328
ab9a4545-0acc-41a6-ae44-4702c02a8582	5446981a-a39f-44cc-a506-72a205d06a99	b4c388a961f5d6b04bdaef2e30cc32a7456f74acf0d443595d4e4eab3304cd6b	okhttp/4.9.2	10.24.67.139	2026-10-19 01:11:51.208	2026-09-19 01:12:05.783	\N	2026-09-19 01:11:51.209
a40b4506-5168-4af8-96a8-1e28cbc3410a	5446981a-a39f-44cc-a506-72a205d06a99	c8e18787d7cc79f84596956d1eb3a16ef8f84e23fcaf01cdaa34990c33873f92	okhttp/4.9.2	10.24.67.139	2026-10-19 01:58:24.745	2026-09-19 01:58:33.58	\N	2026-09-19 01:58:24.753
2293a515-c1e4-47b7-b318-e1aa20f14950	5446981a-a39f-44cc-a506-72a205d06a99	8d312d14181e7c228de9e42c0332217af9cfeb4fbe6eab2420118e5ad4d34f6c	okhttp/4.9.2	10.30.247.23	2026-10-19 02:06:52.195	2026-09-19 02:07:01.594	\N	2026-09-19 02:06:52.196
47d6a7b3-5b06-46cb-bf22-4089dd825715	5446981a-a39f-44cc-a506-72a205d06a99	9cefaf87fa2dcea55b3eef1844304150c6056f2e1af45c01edff871515292d18	okhttp/4.9.2	10.28.174.130	2026-10-19 02:11:48.628	2026-09-19 02:45:39.547	e715bac61b5d8df3064d1ecc44e7001e383bdaa19274e30f82805fcd9187ac89	2026-09-19 02:11:48.629
6db32f88-cb42-4cc3-a295-46418686f466	5446981a-a39f-44cc-a506-72a205d06a99	e715bac61b5d8df3064d1ecc44e7001e383bdaa19274e30f82805fcd9187ac89	okhttp/4.9.2	10.24.67.139	2026-10-19 02:45:39.548	\N	\N	2026-09-19 02:45:39.55
3c5a5a48-aed1-4e14-b54f-f1f5ce093102	5446981a-a39f-44cc-a506-72a205d06a99	fc47ecbeed71bdb9293a2ca240ab73f2ddf24da2531ac3af7c695cf6eda74eab	okhttp/4.9.2	10.28.174.130	2026-10-19 02:45:44.626	2026-09-19 03:07:00.722	6f6a36bb845d2f48a2ced5e3a2277fb90812c78d2634df30c97155bc0ce8877a	2026-09-19 02:45:44.627
97b54fa7-2189-41d8-8b6c-6fd5c51778f8	5446981a-a39f-44cc-a506-72a205d06a99	6f6a36bb845d2f48a2ced5e3a2277fb90812c78d2634df30c97155bc0ce8877a	okhttp/4.9.2	10.30.247.23	2026-10-19 03:07:00.722	2026-09-19 03:37:54.156	c89777dfad3d4a712ead89a7295ccb6bc7badc42f26e40ebc481bdc0f82edbf2	2026-09-19 03:07:00.723
56c86ff3-38f0-455c-b774-ec4d3ddd58d9	5446981a-a39f-44cc-a506-72a205d06a99	6912e281f006daf46ae292fb3b07166ef5b5e2119a1e3c2b7cb22bfa086d9c34	okhttp/4.9.2	10.28.174.130	2026-10-19 03:53:39.751	2026-09-19 04:29:41.1	0379e7bc4dd915aadd54e9a7360dc870575ded315d2ee791123b4aded1c79261	2026-09-19 03:53:39.753
117ef65c-343f-4987-b0a3-1b3f668f84d8	5446981a-a39f-44cc-a506-72a205d06a99	0379e7bc4dd915aadd54e9a7360dc870575ded315d2ee791123b4aded1c79261	okhttp/4.9.2	10.24.67.139	2026-10-19 04:29:41.1	\N	\N	2026-09-19 04:29:41.103
13f81674-f216-4843-a7d0-6bf121cdb72a	5446981a-a39f-44cc-a506-72a205d06a99	cc01445f5c9f83982c242280d6c59a64ba143eb242bcaf3f0e8144f5cd409227	okhttp/4.9.2	10.24.67.139	2026-10-19 04:30:09.238	2026-09-19 05:00:29.18	9d99a85f3e12b1c2b3e3b954fde86b49978bae55665ebe5228f894ca0e71807f	2026-09-19 04:30:09.239
72e5bc82-a6aa-4343-a0a0-12704d2dbb35	5446981a-a39f-44cc-a506-72a205d06a99	9d99a85f3e12b1c2b3e3b954fde86b49978bae55665ebe5228f894ca0e71807f	okhttp/4.9.2	10.28.174.130	2026-10-19 05:00:29.18	2026-09-19 05:39:44.849	5e62f32dc00de1d275c3562258e77aed4cf95c90aaf66033ec35e0f6c68e01ee	2026-09-19 05:00:29.182
3bffba03-b6c1-45d4-9e1f-55c169c1b33b	5446981a-a39f-44cc-a506-72a205d06a99	5e62f32dc00de1d275c3562258e77aed4cf95c90aaf66033ec35e0f6c68e01ee	okhttp/4.9.2	10.28.174.130	2026-10-19 05:39:44.849	\N	\N	2026-09-19 05:39:44.851
511aa390-1e2f-4941-bbda-06781b2d980c	5446981a-a39f-44cc-a506-72a205d06a99	a53e60418742526fa89881294887397993e6b6ba651a0fe475693612a73ee621	okhttp/4.9.2	10.24.67.139	2026-10-19 05:39:46.886	2026-09-19 06:13:56.503	b6ab21e277eafc9053f8c26ee8a64cecebb783da25c07fa8333df71521cc9789	2026-09-19 05:39:46.887
7efd856b-0e54-4959-81f0-c92b9a333591	5446981a-a39f-44cc-a506-72a205d06a99	b6ab21e277eafc9053f8c26ee8a64cecebb783da25c07fa8333df71521cc9789	okhttp/4.9.2	10.24.67.139	2026-10-19 06:13:56.503	\N	\N	2026-09-19 06:13:56.505
\.


--
-- Data for Name: transacciones; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.transacciones (id, cuenta_id, tipo, categoria, nombre, meta, monto, icon, icono_fondo, icono_color, creado_en) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.usuarios (id, correo, telefono, dni, nombre_completo, contrasena_hash, esta_activo, intentos_fallidos, bloqueado_hasta, creado_en, actualizado_en, alerta_compra, alerta_login, alerta_promo, alerta_retiro) FROM stdin;
5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	928020850	76427598	ABRAHAM ARANDA CERNA	$2a$12$ZVfvI54YHTTfy4zeFjkSWuvqhW7ST4etOKU1VXmtfl.5iGmhDoa2e	t	0	\N	2026-09-14 12:17:17.197	2026-09-19 05:39:46.653	t	t	f	t
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: beneficiarios beneficiarios_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.beneficiarios
    ADD CONSTRAINT beneficiarios_pkey PRIMARY KEY (id);


--
-- Name: codigos_verificacion codigos_verificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.codigos_verificacion
    ADD CONSTRAINT codigos_verificacion_pkey PRIMARY KEY (id);


--
-- Name: cuentas cuentas_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cuentas
    ADD CONSTRAINT cuentas_pkey PRIMARY KEY (id);


--
-- Name: eventos_inicio_sesion eventos_inicio_sesion_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.eventos_inicio_sesion
    ADD CONSTRAINT eventos_inicio_sesion_pkey PRIMARY KEY (id);


--
-- Name: eventos_verificacion_facial eventos_verificacion_facial_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.eventos_verificacion_facial
    ADD CONSTRAINT eventos_verificacion_facial_pkey PRIMARY KEY (id);


--
-- Name: notificaciones notificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notificaciones
    ADD CONSTRAINT notificaciones_pkey PRIMARY KEY (id);


--
-- Name: referencias_faciales referencias_faciales_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referencias_faciales
    ADD CONSTRAINT referencias_faciales_pkey PRIMARY KEY (id);


--
-- Name: tokens_renovacion tokens_renovacion_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tokens_renovacion
    ADD CONSTRAINT tokens_renovacion_pkey PRIMARY KEY (id);


--
-- Name: transacciones transacciones_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transacciones
    ADD CONSTRAINT transacciones_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: beneficiarios_usuario_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX beneficiarios_usuario_id_idx ON public.beneficiarios USING btree (usuario_id);


--
-- Name: codigos_verificacion_correo_proposito_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX codigos_verificacion_correo_proposito_idx ON public.codigos_verificacion USING btree (correo, proposito);


--
-- Name: cuentas_cci_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX cuentas_cci_key ON public.cuentas USING btree (cci);


--
-- Name: cuentas_numero_cuenta_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX cuentas_numero_cuenta_key ON public.cuentas USING btree (numero_cuenta);


--
-- Name: cuentas_usuario_id_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX cuentas_usuario_id_key ON public.cuentas USING btree (usuario_id);


--
-- Name: eventos_inicio_sesion_correo_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX eventos_inicio_sesion_correo_idx ON public.eventos_inicio_sesion USING btree (correo);


--
-- Name: eventos_inicio_sesion_usuario_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX eventos_inicio_sesion_usuario_id_idx ON public.eventos_inicio_sesion USING btree (usuario_id);


--
-- Name: eventos_verificacion_facial_dni_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX eventos_verificacion_facial_dni_idx ON public.eventos_verificacion_facial USING btree (dni);


--
-- Name: notificaciones_usuario_id_creado_en_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX notificaciones_usuario_id_creado_en_idx ON public.notificaciones USING btree (usuario_id, creado_en);


--
-- Name: referencias_faciales_usuario_id_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX referencias_faciales_usuario_id_key ON public.referencias_faciales USING btree (usuario_id);


--
-- Name: tokens_renovacion_token_hash_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX tokens_renovacion_token_hash_key ON public.tokens_renovacion USING btree (token_hash);


--
-- Name: tokens_renovacion_usuario_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX tokens_renovacion_usuario_id_idx ON public.tokens_renovacion USING btree (usuario_id);


--
-- Name: transacciones_cuenta_id_creado_en_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX transacciones_cuenta_id_creado_en_idx ON public.transacciones USING btree (cuenta_id, creado_en);


--
-- Name: usuarios_correo_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX usuarios_correo_key ON public.usuarios USING btree (correo);


--
-- Name: usuarios_dni_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX usuarios_dni_key ON public.usuarios USING btree (dni);


--
-- Name: usuarios_telefono_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX usuarios_telefono_key ON public.usuarios USING btree (telefono);


--
-- Name: beneficiarios beneficiarios_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.beneficiarios
    ADD CONSTRAINT beneficiarios_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cuentas cuentas_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.cuentas
    ADD CONSTRAINT cuentas_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eventos_inicio_sesion eventos_inicio_sesion_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.eventos_inicio_sesion
    ADD CONSTRAINT eventos_inicio_sesion_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notificaciones notificaciones_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notificaciones
    ADD CONSTRAINT notificaciones_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: referencias_faciales referencias_faciales_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referencias_faciales
    ADD CONSTRAINT referencias_faciales_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tokens_renovacion tokens_renovacion_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tokens_renovacion
    ADD CONSTRAINT tokens_renovacion_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transacciones transacciones_cuenta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.transacciones
    ADD CONSTRAINT transacciones_cuenta_id_fkey FOREIGN KEY (cuenta_id) REFERENCES public.cuentas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict 27UyqQ3RqTwqd8XDhg6CCEPenbS1dbaAzZddn381ms54SqaixzGc3xvz6QQflgN

