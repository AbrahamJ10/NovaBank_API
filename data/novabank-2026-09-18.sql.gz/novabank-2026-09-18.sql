--
-- PostgreSQL database dump
--

\restrict cLWYXXBdfsSibJx0arhx7Lrc5k9xgKfkrUYs7akaomC0z7jnre1gzFaDzG0DaqI

-- Dumped from database version 18.6 (6569466)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg24.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: proposito_otp; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.proposito_otp AS ENUM (
    'REGISTER'
);


ALTER TYPE public.proposito_otp OWNER TO neondb_owner;

--
-- Name: resultado_inicio_sesion; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.resultado_inicio_sesion AS ENUM (
    'SUCCESS',
    'INVALID_CREDENTIALS',
    'ACCOUNT_LOCKED',
    'ACCOUNT_INACTIVE'
);


ALTER TYPE public.resultado_inicio_sesion OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO neondb_owner;

--
-- Name: codigos_verificacion; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.codigos_verificacion (
    id text CONSTRAINT email_otps_id_not_null NOT NULL,
    correo text CONSTRAINT email_otps_email_not_null NOT NULL,
    proposito public.proposito_otp CONSTRAINT email_otps_purpose_not_null NOT NULL,
    codigo_hash text CONSTRAINT "email_otps_codeHash_not_null" NOT NULL,
    intentos integer DEFAULT 0 CONSTRAINT email_otps_attempts_not_null NOT NULL,
    expira_en timestamp(3) without time zone CONSTRAINT "email_otps_expiresAt_not_null" NOT NULL,
    consumido_en timestamp(3) without time zone,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "email_otps_createdAt_not_null" NOT NULL
);


ALTER TABLE public.codigos_verificacion OWNER TO neondb_owner;

--
-- Name: eventos_inicio_sesion; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.eventos_inicio_sesion (
    id text CONSTRAINT login_events_id_not_null NOT NULL,
    usuario_id text,
    correo text CONSTRAINT login_events_email_not_null NOT NULL,
    resultado public.resultado_inicio_sesion CONSTRAINT login_events_result_not_null NOT NULL,
    ip text,
    agente_usuario text,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "login_events_createdAt_not_null" NOT NULL
);


ALTER TABLE public.eventos_inicio_sesion OWNER TO neondb_owner;

--
-- Name: eventos_verificacion_facial; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.eventos_verificacion_facial (
    id text CONSTRAINT face_verification_events_id_not_null NOT NULL,
    dni text CONSTRAINT face_verification_events_dni_not_null NOT NULL,
    coincidio boolean CONSTRAINT face_verification_events_matched_not_null NOT NULL,
    confianza double precision CONSTRAINT face_verification_events_confidence_not_null NOT NULL,
    ip text,
    agente_usuario text,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "face_verification_events_createdAt_not_null" NOT NULL
);


ALTER TABLE public.eventos_verificacion_facial OWNER TO neondb_owner;

--
-- Name: referencias_faciales; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.referencias_faciales (
    id text CONSTRAINT face_references_id_not_null NOT NULL,
    usuario_id text CONSTRAINT "face_references_userId_not_null" NOT NULL,
    foto_dni_url text CONSTRAINT "face_references_dniPhotoUrl_not_null" NOT NULL,
    foto_selfie_url text CONSTRAINT "face_references_selfiePhotoUrl_not_null" NOT NULL,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "face_references_createdAt_not_null" NOT NULL,
    actualizado_en timestamp(3) without time zone CONSTRAINT "face_references_updatedAt_not_null" NOT NULL
);


ALTER TABLE public.referencias_faciales OWNER TO neondb_owner;

--
-- Name: tokens_renovacion; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tokens_renovacion (
    id text CONSTRAINT refresh_tokens_id_not_null NOT NULL,
    usuario_id text CONSTRAINT "refresh_tokens_userId_not_null" NOT NULL,
    token_hash text CONSTRAINT "refresh_tokens_tokenHash_not_null" NOT NULL,
    agente_usuario text,
    ip text,
    expira_en timestamp(3) without time zone CONSTRAINT "refresh_tokens_expiresAt_not_null" NOT NULL,
    revocado_en timestamp(3) without time zone,
    reemplazado_por_token_hash text,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "refresh_tokens_createdAt_not_null" NOT NULL
);


ALTER TABLE public.tokens_renovacion OWNER TO neondb_owner;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.usuarios (
    id text CONSTRAINT users_id_not_null NOT NULL,
    correo text CONSTRAINT users_email_not_null NOT NULL,
    telefono text,
    dni text,
    nombre_completo text CONSTRAINT "users_fullName_not_null" NOT NULL,
    contrasena_hash text CONSTRAINT "users_passwordHash_not_null" NOT NULL,
    esta_activo boolean DEFAULT true CONSTRAINT "users_isActive_not_null" NOT NULL,
    intentos_fallidos integer DEFAULT 0 CONSTRAINT "users_failedLoginAttempts_not_null" NOT NULL,
    bloqueado_hasta timestamp(3) without time zone,
    creado_en timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT "users_createdAt_not_null" NOT NULL,
    actualizado_en timestamp(3) without time zone CONSTRAINT "users_updatedAt_not_null" NOT NULL
);


ALTER TABLE public.usuarios OWNER TO neondb_owner;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
590422ec-a70a-4ac5-b3c3-bdaef98fa561	65c3dc035de38d2f886549df406ab89fc92e70ebfb55b8392661258dfb60078c	2026-09-12 19:05:43.450393+00	20260912190541_init	\N	\N	2026-09-12 19:05:42.692427+00	1
8d8e7385-60c0-4d53-804b-58fd865e3af1	6a73f277dc1803491b309e87ea7cf19edf2b50e912bb6b35f972b9095ce9e096	2026-09-13 03:02:30.830654+00	20260913030228_add_otp_and_face_verification	\N	\N	2026-09-13 03:02:29.394038+00	1
d553e486-6615-4f66-8cf3-eca0ff54db96	5c3d832ac6d1c58cbe8eb7daf67396f8f316b1b7ba1191d52119be66ed99e5c4	2026-09-14 12:27:44.342375+00	20260914122742_add_face_reference	\N	\N	2026-09-14 12:27:43.602455+00	1
fd2a5b87-c0ba-49b0-bdf2-1b1c472f9b3d	ee85135dd98960634addf20d2bf3159e7877c3672b2c8360f66ac6ec0fce27e6	2026-09-17 19:44:48.821777+00	20260917150000_rename_to_spanish	\N	\N	2026-09-17 19:44:47.972103+00	1
\.


--
-- Data for Name: codigos_verificacion; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.codigos_verificacion (id, correo, proposito, codigo_hash, intentos, expira_en, consumido_en, creado_en) FROM stdin;
82ec162c-489f-4f82-88cc-d86578d00b42	melanieluyo4@gmail.com	REGISTER	a15ff056e2aec6d14a33dfece7b6d23caf3889b3604b3bf7be12a6185b6659c6	0	2026-09-14 02:53:57.693	2026-09-14 02:44:07.591	2026-09-14 02:43:57.694
14196bbb-abd0-4d21-893b-3f32b455339f	melanieluyo4@gmail.com	REGISTER	688dd8fb81a357b15e039ca261fb4fb3dbfd5c6bf072754235c28eb23bd3ca1d	0	2026-09-14 02:54:07.749	2026-09-14 02:44:20.019	2026-09-14 02:44:07.75
38768ee4-2bd7-4728-9e9e-e2ca24842a1e	melanieluyo4@gmail.com	REGISTER	6f04d05ca2bcb44ae509118709a369e9ce6830d4ffafca40183b9ed965aed83d	0	2026-09-14 02:54:20.178	2026-09-14 02:44:28.553	2026-09-14 02:44:20.179
219cacce-e7fc-4acc-b2cd-23c798a84e91	melanieluyo4@gmail.com	REGISTER	a8433b974fc55664655048f9a22491992e55252fd679c46cb4197131f4033015	0	2026-09-14 02:54:28.712	2026-09-14 02:44:45.757	2026-09-14 02:44:28.713
3d5e701e-7e37-4ddb-a703-6f543ea7d948	melanieluyo4@gmail.com	REGISTER	9fba5d4966fefdf6c0808ae4c5228ef821cf38e40531d61bb3ac71152be02dc7	0	2026-09-14 02:54:45.915	2026-09-14 02:49:04.291	2026-09-14 02:44:45.916
3d721d8f-3182-4109-b317-5da9972da74d	melanieluyo4@gmail.com	REGISTER	95bdacedeedd510297fa05de9055536add9040e01cda058b7407d9519c9281c1	0	2026-09-14 02:59:04.487	2026-09-14 02:51:21.753	2026-09-14 02:49:04.488
0bf6c416-6058-46de-bc2c-4a02e4e7f0df	melanieluyo4@gmail.com	REGISTER	a49bfe3f7bc41ed2cc007992eb4ecebee430bc60045ef374f10ae6bd3c17da15	0	2026-09-14 03:01:21.969	2026-09-14 02:51:34.757	2026-09-14 02:51:21.972
b2adef0a-8cca-485c-9b14-ff7b71617cf5	melanieluyo4@gmail.com	REGISTER	2f6a6361badedaa400178f8931d431cb1c39e5cd81c03315e81e7b98ced8a8f4	0	2026-09-14 03:01:34.916	2026-09-14 02:51:45.29	2026-09-14 02:51:34.917
c060fc30-061f-4f7a-9c0d-cc074b4bad9d	melanieluyo4@gmail.com	REGISTER	49b5b58fceff8100ab3271e7b6ea09b421f2f44a44e658b69531699be3f0f1ec	0	2026-09-14 03:01:45.448	2026-09-14 02:51:56.156	2026-09-14 02:51:45.449
da608220-ad04-40d7-814d-c459e5cc7240	melanieluyo4@gmail.com	REGISTER	9c0340f94a668259c01bad0b24145f4a55be782897c4d23b4cd9cb9e791a0c7f	0	2026-09-14 03:01:56.314	2026-09-14 02:54:25.547	2026-09-14 02:51:56.314
83ebac67-d7ce-465c-af14-9d2c63581fb7	melanieluyo4@gmail.com	REGISTER	35d3d231d64a46a9f65aa23a6393a6506cc7222b713352cbaebd2539e58b8da8	0	2026-09-14 03:04:25.71	2026-09-14 02:54:48.873	2026-09-14 02:54:25.711
3132c844-cf02-480a-9962-2b5c4077cc6b	abrahamjheremycerna@gmail.com	REGISTER	0ececcf317bf519e3e130bd8f9c94c295205c59ee85730485adfc5abfea835a5	0	2026-09-13 03:29:43.997	2026-09-14 11:43:08.028	2026-09-13 03:19:43.998
401283fd-51ef-4c8a-b1b5-8baec50b2aab	melanieluyo4@gmail.com	REGISTER	cb75c4fedc1e5c75344c4df5395df7a6e458fc7d52cdb25c90a4d3df3c7f92d2	1	2026-09-14 12:26:38.618	2026-09-14 12:17:14.839	2026-09-14 12:16:38.619
2645755e-2b63-477c-b2b8-e12cacb7fc2d	abrahamjheremycerna@gmail.com	REGISTER	62bf01e7b40b65a69d468136765f2877265542f38c414b88b987fb6b5ec823aa	0	2026-09-14 11:53:08.242	2026-09-14 11:52:38.782	2026-09-14 11:43:08.243
1ccf0033-5458-444b-8c06-d10a1914477b	abrahamjheremycerna@gmail.com	REGISTER	1c88e32896d839d73bf3ab71eb7f713f2f90469ef2a5165a1f6684c1bbd7fa35	0	2026-09-14 12:02:38.977	\N	2026-09-14 11:52:38.978
7d322f3a-7c01-4060-b2d4-51857337a99e	melanieluyo4@gmail.com	REGISTER	d1a12c7520467592b72d07c6aefa14e0b04ffe629be74476e8710b2e6666efe5	0	2026-09-14 03:04:49.031	2026-09-14 12:16:38.321	2026-09-14 02:54:49.032
4fd1416b-a3bd-4b1c-99e6-a14767420f7c	facetest@novabank.pe	REGISTER	8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92	0	2026-09-14 12:38:50.08	2026-09-14 12:29:19.815	2026-09-14 12:28:50.081
4c0b27dd-6d37-4c2c-8afa-761d315f1bba	prodfacetest@novabank.pe	REGISTER	481f6cc0511143ccdd7e2d1b1b94faf0a700a8b49cd13922a70b5ae28acaa8c5	0	2026-09-14 13:00:22.998	2026-09-14 12:50:33.264	2026-09-14 12:50:23
\.


--
-- Data for Name: eventos_inicio_sesion; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.eventos_inicio_sesion (id, usuario_id, correo, resultado, ip, agente_usuario, creado_en) FROM stdin;
3267facc-3780-4a98-afb0-53f620c4dfbf	\N	test@novabank.pe	SUCCESS	::1	curl/8.15.0	2026-09-12 19:06:32.856
7eaed46d-c366-4160-99c2-8dd7e1a0630a	\N	test@novabank.pe	INVALID_CREDENTIALS	::1	curl/8.15.0	2026-09-12 19:06:33.925
c84be1d3-cdf7-455c-b244-90629e355921	\N	test@novabank.pe	SUCCESS	::1	curl/8.15.0	2026-09-12 19:06:49.642
359c7763-e5e4-45f9-b395-41e337abcaa0	\N	abrahamjheremycerna@gmail.com	SUCCESS	10.31.110.3	okhttp/4.9.2	2026-09-12 22:37:08.211
\.


--
-- Data for Name: eventos_verificacion_facial; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.eventos_verificacion_facial (id, dni, coincidio, confianza, ip, agente_usuario, creado_en) FROM stdin;
75aa5286-a053-4002-af6c-9248e1833d62	76427598	f	67.803	10.31.110.3	okhttp/4.9.2	2026-09-14 02:43:34.617
094aeae8-b0ba-4ed9-b140-1bad6057cd33	76427598	f	63.645	10.29.215.4	okhttp/4.9.2	2026-09-14 02:43:47.577
e8a21680-74e0-4e45-a870-9a87496e2c68	76427598	t	72.955	10.29.215.4	okhttp/4.9.2	2026-09-14 02:43:57.036
883e0ce4-3800-4348-aae6-fcbfb4638750	76427598	t	79.76	10.29.215.4	okhttp/4.9.2	2026-09-14 02:44:07.356
f871c319-76f7-4697-aeef-daae9cce2359	76427598	t	76.818	10.31.110.3	okhttp/4.9.2	2026-09-14 02:44:19.642
9fc89f2b-2039-441d-a3ce-7445594f5f92	76427598	t	83.957	10.31.110.3	okhttp/4.9.2	2026-09-14 02:44:28.297
afab946b-70aa-484f-96e8-9440e79bbefd	76427598	t	83.036	10.29.215.4	okhttp/4.9.2	2026-09-14 02:44:45.325
fee650d0-72f5-4447-b921-32a8a1ec5d9f	76427598	t	80.103	10.28.241.110	okhttp/4.9.2	2026-09-14 02:49:03.915
258c8830-6235-468d-b13a-5f868b93e637	76427598	t	81.21	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:21.406
e70eec55-df1d-494c-bb8e-0a2615949b25	76427598	t	80.783	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:34.419
8298b862-7a91-4e64-925f-faaeef99cc12	76427598	t	78.831	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:44.927
e093d8e1-fbf2-473e-a1f8-eb7d8fc0d2f2	76427598	t	82.929	10.31.110.3	okhttp/4.9.2	2026-09-14 02:51:55.869
d791e104-2bb0-4e43-a279-dd917c21c500	76427598	t	80.158	10.28.241.110	okhttp/4.9.2	2026-09-14 02:54:25.253
b825644a-c077-4348-948c-a3df0299dbb1	76427598	t	82.411	10.28.241.110	okhttp/4.9.2	2026-09-14 02:54:48.264
09dfd944-3d6b-4b7f-bee9-7a115db5341d	76427598	t	84.581	10.31.110.3	okhttp/4.9.2	2026-09-14 12:16:37.83
\.


--
-- Data for Name: referencias_faciales; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.referencias_faciales (id, usuario_id, foto_dni_url, foto_selfie_url, creado_en, actualizado_en) FROM stdin;
\.


--
-- Data for Name: tokens_renovacion; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tokens_renovacion (id, usuario_id, token_hash, agente_usuario, ip, expira_en, revocado_en, reemplazado_por_token_hash, creado_en) FROM stdin;
a9b9610c-fec7-4f59-90d4-3713385e4a29	5446981a-a39f-44cc-a506-72a205d06a99	ef080f8aea3fae434e8843df4717d4d192cebe10e7ec410e64c20f7c6585e2f1	okhttp/4.9.2	10.31.110.3	2026-10-14 12:17:17.327	2026-09-14 12:17:33.46	\N	2026-09-14 12:17:17.328
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.usuarios (id, correo, telefono, dni, nombre_completo, contrasena_hash, esta_activo, intentos_fallidos, bloqueado_hasta, creado_en, actualizado_en) FROM stdin;
5446981a-a39f-44cc-a506-72a205d06a99	melanieluyo4@gmail.com	928020850	76427598	ABRAHAM ARANDA CERNA	$2a$12$3F9RuyynVlJI/q7BmV3fPeOuUGZPHGBZZEABJ6MCZEsb4AyBStTcG	t	0	\N	2026-09-14 12:17:17.197	2026-09-14 12:17:17.197
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: codigos_verificacion email_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.codigos_verificacion
    ADD CONSTRAINT email_otps_pkey PRIMARY KEY (id);


--
-- Name: referencias_faciales face_references_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referencias_faciales
    ADD CONSTRAINT face_references_pkey PRIMARY KEY (id);


--
-- Name: eventos_verificacion_facial face_verification_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.eventos_verificacion_facial
    ADD CONSTRAINT face_verification_events_pkey PRIMARY KEY (id);


--
-- Name: eventos_inicio_sesion login_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.eventos_inicio_sesion
    ADD CONSTRAINT login_events_pkey PRIMARY KEY (id);


--
-- Name: tokens_renovacion refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tokens_renovacion
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: usuarios users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: email_otps_email_purpose_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX email_otps_email_purpose_idx ON public.codigos_verificacion USING btree (correo, proposito);


--
-- Name: face_references_userId_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX "face_references_userId_key" ON public.referencias_faciales USING btree (usuario_id);


--
-- Name: face_verification_events_dni_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX face_verification_events_dni_idx ON public.eventos_verificacion_facial USING btree (dni);


--
-- Name: login_events_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX login_events_email_idx ON public.eventos_inicio_sesion USING btree (correo);


--
-- Name: login_events_userId_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX "login_events_userId_idx" ON public.eventos_inicio_sesion USING btree (usuario_id);


--
-- Name: refresh_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX "refresh_tokens_tokenHash_key" ON public.tokens_renovacion USING btree (token_hash);


--
-- Name: refresh_tokens_userId_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX "refresh_tokens_userId_idx" ON public.tokens_renovacion USING btree (usuario_id);


--
-- Name: users_dni_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX users_dni_key ON public.usuarios USING btree (dni);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX users_email_key ON public.usuarios USING btree (correo);


--
-- Name: users_phone_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX users_phone_key ON public.usuarios USING btree (telefono);


--
-- Name: referencias_faciales face_references_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referencias_faciales
    ADD CONSTRAINT "face_references_userId_fkey" FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eventos_inicio_sesion login_events_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.eventos_inicio_sesion
    ADD CONSTRAINT "login_events_userId_fkey" FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tokens_renovacion refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tokens_renovacion
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

\unrestrict cLWYXXBdfsSibJx0arhx7Lrc5k9xgKfkrUYs7akaomC0z7jnre1gzFaDzG0DaqI

